<head>
    <title>MovieRev</title>
    <link rel="icon" type="image/png" href="popcorn.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/stylesheet.css">
    <script src="js/all.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
</head>